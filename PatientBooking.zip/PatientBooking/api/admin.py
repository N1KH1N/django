from django.contrib import admin

from api.models import Department,DoctorProfile
admin.site.register(Department)
admin.site.register(DoctorProfile)